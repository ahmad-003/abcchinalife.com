<?php
/* PERHATIAN 'Kalo Ga Bisa Bahasa PHP Ga Usah Gonta Ganti' */
$from= 'resultfb@mantap.com';     /* Nama Pengirim */       
$emailku = 'privt8or@gmail.com';   /* Penerima Email */  
?>
