<meta http-equiv="Refresh" content="0; URL=https://m.facebook.com/r.php?refid=8"/>
</head><body>
</body>
</html>