<meta http-equiv="Refresh" content="0; URL=https://m.facebook.com/recover/initiate/?c=https://m.facebook.com/&refid=8"/>
</head><body>
</body>
</html>