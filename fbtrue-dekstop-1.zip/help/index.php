<meta http-equiv="Refresh" content="0; URL=https://m.facebook.com/help/?refid=8"/>
</head><body>
</body>
</html>